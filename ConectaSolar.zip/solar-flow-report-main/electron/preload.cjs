const { contextBridge } = require("electron");

// Expose a safe API to the renderer if needed in the future.
// For now the app runs as a regular web app inside Electron.
contextBridge.exposeInMainWorld("solana", {
  platform: process.platform,
});

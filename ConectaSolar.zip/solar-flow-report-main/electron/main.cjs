const { app, BrowserWindow } = require("electron");
const path = require("path");
const { spawn } = require("child_process");

let serverProcess = null;
let serverPort = null;

function startServer() {
  return new Promise((resolve, reject) => {
    const serverScript = path.join(__dirname, "..", "electron-bridge", "server.cjs");
    serverProcess = spawn(process.execPath, [serverScript], {
      stdio: ["ignore", "pipe", "pipe"],
    });

    let output = "";
    const onData = (data) => {
      output += data.toString();
      const match = output.match(/http:\/\/localhost:(\d+)/);
      if (match && !serverPort) {
        serverPort = parseInt(match[1], 10);
        resolve(serverPort);
      }
    };

    serverProcess.stdout.on("data", onData);
    serverProcess.stderr.on("data", onData);

    serverProcess.on("error", reject);
    serverProcess.on("exit", (code) => {
      if (!serverPort) {
        reject(new Error(`Server exited with code ${code}`));
      }
    });

    setTimeout(() => {
      if (!serverPort) {
        reject(new Error("Server did not start in time"));
      }
    }, 15000);
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 375,
    minHeight: 700,
    title: "Solana — Monitoramento de Usinas Solares",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, "preload.cjs"),
    },
  });

  win.loadURL(`http://localhost:${serverPort}/`);

  if (process.env.ELECTRON_ENV === "dev") {
    win.webContents.openDevTools();
  }
}

app.whenReady().then(async () => {
  try {
    await startServer();
    createWindow();
  } catch (err) {
    console.error("Failed to start Solana server:", err);
    app.quit();
  }

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("before-quit", () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

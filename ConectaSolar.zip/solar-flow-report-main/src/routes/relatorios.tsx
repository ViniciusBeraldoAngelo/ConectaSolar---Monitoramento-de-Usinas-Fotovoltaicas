import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FileBarChart, FileDown, Sun, Plug, Scale } from "lucide-react";
import { AppSidebar } from "@/components/AppSidebar";
import { EnergyChart } from "@/components/EnergyChart";
import {
  getGenerationData,
  getInvoices,
  formatKwh,
  formatBRL,
} from "@/lib/solar-data";

export const Route = createFileRoute("/relatorios")({
  head: () => ({
    meta: [
      { title: "Relatórios — Conecta Solar" },
      {
        name: "description",
        content:
          "Gere relatórios de geração solar e de consumo a partir das faturas de energia.",
      },
      { property: "og:title", content: "Relatórios — Conecta Solar" },
      {
        property: "og:description",
        content: "Relatórios de geração e consumo da sua usina solar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReportsPage,
});

type Tipo = "geracao" | "consumo" | "comparativo";

const TIPOS: { key: Tipo; label: string; desc: string; icon: typeof Sun }[] = [
  { key: "geracao", label: "Geração", desc: "Produção da usina no período", icon: Sun },
  { key: "consumo", label: "Consumo", desc: "Dados das faturas da concessionária", icon: Plug },
  { key: "comparativo", label: "Comparativo", desc: "Geração vs consumo lado a lado", icon: Scale },
];

function ReportsPage() {
  const [tipo, setTipo] = useState<Tipo>("comparativo");
  const [de, setDe] = useState("2026-01-01");
  const [ate, setAte] = useState("2026-08-27");
  const [gerado, setGerado] = useState(false);

  const geracao = useMemo(() => getGenerationData("ano"), [de, ate]);
  const invoices = useMemo(() => getInvoices(), []);
  const consumo = geracao.map((d, i) => ({
    label: d.label,
    kwh: invoices[i % invoices.length]?.consumoKwh ?? 380,
  }));

  const totalGeracao = geracao.reduce((s, d) => s + d.kwh, 0);
  const totalConsumo = consumo.reduce((s, d) => s + d.kwh, 0);
  const economia = totalGeracao * 0.92;

  const dadosGrafico =
    tipo === "consumo" ? consumo : geracao;
  const dadosComparativo = tipo === "comparativo" ? consumo : undefined;

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="px-5 pt-8 pb-28 lg:pb-12 lg:pl-72 lg:pr-10">
        <div className="mx-auto max-w-5xl">
          <header className="fade-up">
            <h1 className="text-3xl font-bold tracking-tight">Relatórios</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Gere análises de geração e consumo em segundos.
            </p>
          </header>

          {/* Configuração do relatório */}
          <section className="fade-up mt-6 rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-semibold">Tipo de relatório</h2>
            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
              {TIPOS.map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTipo(t.key)}
                  aria-pressed={tipo === t.key}
                  className={`flex items-start gap-3 rounded-xl border p-4 text-left transition-all ${
                    tipo === t.key
                      ? "border-primary bg-primary-soft"
                      : "border-border hover:border-primary/40"
                  }`}
                >
                  <t.icon className={`mt-0.5 size-5 ${tipo === t.key ? "text-primary" : "text-muted-foreground"}`} />
                  <span>
                    <span className="block text-sm font-semibold">{t.label}</span>
                    <span className="mt-0.5 block text-xs text-muted-foreground">{t.desc}</span>
                  </span>
                </button>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap items-end gap-3">
              <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
                De
                <input
                  type="date"
                  value={de}
                  onChange={(e) => setDe(e.target.value)}
                  className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground focus:ring-2 focus:ring-ring focus:outline-none"
                />
              </label>
              <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
                Até
                <input
                  type="date"
                  value={ate}
                  onChange={(e) => setAte(e.target.value)}
                  className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground focus:ring-2 focus:ring-ring focus:outline-none"
                />
              </label>
              <button
                onClick={() => setGerado(true)}
                className="flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
              >
                <FileBarChart className="size-4" />
                Gerar relatório
              </button>
            </div>
          </section>

          {/* Pré-visualização */}
          {gerado && (
            <section className="fade-up mt-6 rounded-2xl border border-border bg-card p-6 sm:p-8">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="font-display text-xl font-bold">
                    Relatório {TIPOS.find((t) => t.key === tipo)?.label}
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    Período: {new Date(de + "T00:00").toLocaleDateString("pt-BR")} —{" "}
                    {new Date(ate + "T00:00").toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <button className="flex items-center gap-2 rounded-xl border border-border px-4 py-2 text-sm font-semibold transition-colors hover:bg-muted">
                  <FileDown className="size-4" />
                  Baixar PDF
                </button>
              </div>

              <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="rounded-xl bg-muted p-4">
                  <p className="text-xs text-muted-foreground">Geração total</p>
                  <p className="mt-1 font-display text-xl font-bold">{formatKwh(totalGeracao)} kWh</p>
                </div>
                <div className="rounded-xl bg-muted p-4">
                  <p className="text-xs text-muted-foreground">Consumo total</p>
                  <p className="mt-1 font-display text-xl font-bold">{formatKwh(totalConsumo)} kWh</p>
                </div>
                <div className="rounded-xl bg-primary-soft p-4">
                  <p className="text-xs text-primary">Economia estimada</p>
                  <p className="mt-1 font-display text-xl font-bold text-primary">{formatBRL(economia)}</p>
                </div>
              </div>

              <div className="mt-6">
                <EnergyChart data={dadosGrafico} compareData={dadosComparativo} />
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

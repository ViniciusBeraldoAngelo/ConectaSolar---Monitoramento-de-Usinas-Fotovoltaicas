import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FileText, Download, X, Search } from "lucide-react";
import { AppSidebar } from "@/components/AppSidebar";
import {
  getInvoices,
  formatBRL,
  type Invoice,
} from "@/lib/solar-data";

export const Route = createFileRoute("/faturas")({
  head: () => ({
    meta: [
      { title: "Faturas de Energia — Conecta Solar" },
      {
        name: "description",
        content:
          "Visualize e baixe as faturas de energia da concessionária diretamente no aplicativo.",
      },
      { property: "og:title", content: "Faturas de Energia — Conecta Solar" },
      {
        property: "og:description",
        content: "Suas faturas da concessionária em um só lugar.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: InvoicesPage,
});

const STATUS_STYLE: Record<Invoice["status"], string> = {
  paga: "bg-success/10 text-success",
  pendente: "bg-primary-soft text-primary",
  vencida: "bg-destructive/10 text-destructive",
};

const STATUS_LABEL: Record<Invoice["status"], string> = {
  paga: "Paga",
  pendente: "Pendente",
  vencida: "Vencida",
};

function InvoicesPage() {
  const invoices = useMemo(() => getInvoices(), []);
  const [busca, setBusca] = useState("");
  const [filtro, setFiltro] = useState<"todas" | Invoice["status"]>("todas");
  const [aberta, setAberta] = useState<Invoice | null>(null);

  const filtradas = invoices.filter(
    (f) =>
      (filtro === "todas" || f.status === filtro) &&
      f.mes.toLowerCase().includes(busca.toLowerCase()),
  );

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="px-5 pt-8 pb-28 lg:pb-12 lg:pl-72 lg:pr-10">
        <div className="mx-auto max-w-5xl">
          <header className="fade-up">
            <h1 className="text-3xl font-bold tracking-tight">Faturas</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Faturas da sua concessionária, sempre à mão.
            </p>
          </header>

          {/* Filtros */}
          <div className="fade-up mt-6 flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                placeholder="Buscar por mês…"
                className="rounded-xl border border-input bg-card py-2 pr-3 pl-9 text-sm focus:ring-2 focus:ring-ring focus:outline-none"
              />
            </div>
            <div className="flex rounded-xl border border-border bg-card p-1">
              {(["todas", "paga", "pendente"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFiltro(f)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition-all ${
                    filtro === f
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {f === "todas" ? "Todas" : f === "paga" ? "Pagas" : "Pendentes"}
                </button>
              ))}
            </div>
          </div>

          {/* Lista */}
          <div className="mt-6 space-y-3">
            {filtradas.map((f, i) => (
              <button
                key={f.id}
                onClick={() => setAberta(f)}
                className="fade-up flex w-full items-center gap-4 rounded-2xl border border-border bg-card p-4 text-left transition-colors hover:border-primary/40"
                style={{ animationDelay: `${i * 40}ms` }}
              >
                <div className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary">
                  <FileText className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{f.mes}</p>
                  <p className="text-xs text-muted-foreground">
                    {f.concessionaria} • Consumo {f.consumoKwh} kWh
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold">{formatBRL(f.valor)}</p>
                  <span
                    className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${STATUS_STYLE[f.status]}`}
                  >
                    {STATUS_LABEL[f.status]}
                  </span>
                </div>
              </button>
            ))}
            {filtradas.length === 0 && (
              <p className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
                Nenhuma fatura encontrada para esse filtro.
              </p>
            )}
          </div>
        </div>
      </main>

      {/* Modal da fatura */}
      {aberta && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-foreground/40 p-4 backdrop-blur-sm"
          onClick={() => setAberta(null)}
          role="dialog"
          aria-modal="true"
          aria-label={`Fatura de ${aberta.mes}`}
        >
          <div
            className="fade-up w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-display text-xl font-bold">
                  Fatura {aberta.mes}
                </h2>
                <p className="text-xs text-muted-foreground">
                  {aberta.concessionaria} • Competência {aberta.competencia}
                </p>
              </div>
              <button
                onClick={() => setAberta(null)}
                className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted"
                aria-label="Fechar"
              >
                <X className="size-4" />
              </button>
            </div>

            <dl className="mt-5 space-y-3 rounded-xl bg-muted p-4 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Consumo</dt>
                <dd className="font-semibold">{aberta.consumoKwh} kWh</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Energia compensada (solar)</dt>
                <dd className="font-semibold text-success">-318 kWh</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Vencimento</dt>
                <dd className="font-semibold">{aberta.vencimento}</dd>
              </div>
              <div className="flex justify-between border-t border-border pt-3">
                <dt className="font-medium">Total</dt>
                <dd className="font-display text-lg font-bold">
                  {formatBRL(aberta.valor)}
                </dd>
              </div>
            </dl>

            <button className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90">
              <Download className="size-4" />
              Baixar PDF da fatura
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

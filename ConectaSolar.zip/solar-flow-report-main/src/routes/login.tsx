import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Sun, Mail, Lock, ArrowRight, ShieldCheck, TrendingUp, Leaf } from "lucide-react";
import { signIn } from "@/lib/auth";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — Conecta Solar Monitor Solar" },
      {
        name: "description",
        content:
          "Acesse o Conecta Solar para acompanhar a geração da sua usina solar, faturas e relatórios.",
      },
      { property: "og:title", content: "Entrar — Conecta Solar Monitor Solar" },
      {
        property: "og:description",
        content: "Faça login e acompanhe sua usina solar em tempo real.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LoginPage,
});

const DESTAQUES = [
  { icon: TrendingUp, texto: "Geração por dia, semana, mês, ano ou período" },
  { icon: Leaf, texto: "Economia e CO₂ evitado sempre à vista" },
  { icon: ShieldCheck, texto: "Faturas da concessionária dentro do app" },
];

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setErro("Informe um e-mail válido.");
      return;
    }
    setErro(null);
    setCarregando(true);
    signIn(email);
    setTimeout(() => navigate({ to: "/", replace: true }), 350);
  };

  return (
    <div className="grid min-h-screen bg-background lg:grid-cols-2">
      {/* Painel visual */}
      <div className="relative hidden overflow-hidden bg-primary p-12 lg:flex lg:flex-col lg:justify-between">
        {/* Grade fotovoltaica deslizando */}
        <div className="grid-drift pointer-events-none absolute inset-0 opacity-60" aria-hidden />

        {/* Aurora de fundo */}
        <div
          className="aurora pointer-events-none absolute -left-1/4 top-1/4 h-[36rem] w-[48rem] rounded-full blur-3xl"
          style={{
            background:
              "radial-gradient(closest-side, var(--color-chart-2), transparent 70%)",
          }}
          aria-hidden
        />

        <div
          className="orb-drift pointer-events-none absolute -right-24 -top-24 size-96 rounded-full opacity-30 blur-3xl"
          style={{ background: "var(--color-chart-4)" }}
          aria-hidden
        />
        <div
          className="orb-drift-slow pointer-events-none absolute -bottom-32 -left-20 size-96 rounded-full opacity-20 blur-3xl"
          style={{ background: "var(--color-chart-2)" }}
          aria-hidden
        />

        {/* Sol com raios girando */}
        <div
          className="pointer-events-none absolute -right-16 top-16 size-80 opacity-40"
          aria-hidden
        >
          <div className="ray-spin absolute inset-0">
            {Array.from({ length: 12 }).map((_, i) => (
              <span
                key={i}
                className="absolute left-1/2 top-1/2 h-40 w-px origin-top bg-gradient-to-b from-primary-foreground/45 to-transparent"
                style={{ transform: `rotate(${i * 30}deg)` }}
              />
            ))}
          </div>
          <div className="ray-spin-reverse absolute inset-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <span
                key={i}
                className="absolute left-1/2 top-1/2 h-28 w-px origin-top bg-gradient-to-b from-primary-foreground/30 to-transparent"
                style={{ transform: `rotate(${i * 60 + 15}deg)` }}
              />
            ))}
          </div>
        </div>

        {/* Linhas de energia deslizando suavemente */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
          {[20, 45, 72].map((left, i) => (
            <span
              key={left}
              className="line-sweep absolute top-0 h-24 w-px bg-gradient-to-b from-transparent via-primary-foreground/40 to-transparent"
              style={{ left: `${left}%`, animationDelay: `${i * 3}s` }}
            />
          ))}
        </div>

        {/* Partículas de energia subindo */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
          {[8, 24, 38, 55, 66, 81, 92].map((left, i) => (
            <span
              key={left}
              className="particle-rise absolute bottom-24 size-1 rounded-full bg-primary-foreground/70"
              style={{ left: `${left}%`, animationDelay: `${i * 1.4}s` }}
            />
          ))}
        </div>

        {/* Horizonte com barrinhas de geração */}
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 h-32 overflow-hidden"
          aria-hidden
        >
          <div className="absolute inset-x-0 bottom-16 flex items-end justify-center gap-1.5 px-12 opacity-40">
            {[14, 22, 30, 20, 36, 26, 44, 30, 38, 24, 32, 18].map((h, i) => (
              <span
                key={i}
                className="bar-breathe w-2 rounded-t-sm bg-primary-foreground/60"
                style={{ height: `${h}px`, animationDelay: `${i * 0.22}s` }}
              />
            ))}
          </div>
          <div className="absolute inset-x-0 bottom-16 h-px overflow-hidden bg-primary-foreground/20">
            <span className="shine-x block h-px w-1/3 bg-primary-foreground/70" />
          </div>
        </div>

        <div className="relative flex items-center gap-2.5 text-primary-foreground">
          <div className="relative grid size-10 place-items-center rounded-xl bg-primary-foreground/15 backdrop-blur">
            <span
              className="halo-pulse absolute inset-0 rounded-xl ring-1 ring-primary-foreground/50"
              aria-hidden
            />
            <span
              className="ring-expand absolute inset-0 rounded-xl ring-1 ring-primary-foreground/30"
              style={{ animationDelay: "1.5s" }}
              aria-hidden
            />
            <Sun className="size-5" />
          </div>
          <span className="font-display text-xl font-bold tracking-tight">Conecta Solar</span>
        </div>

        <div className="relative text-primary-foreground">
          <h2 className="font-display text-4xl font-bold leading-tight tracking-tight">
            Sua usina solar,
            <br />
            clara como o dia.
          </h2>
          <p className="mt-4 max-w-sm text-sm text-primary-foreground/80">
            Monitoramento sem poluição visual: só o que importa para você entender
            quanto gera, quanto economiza e o que fazer em seguida.
          </p>
          <ul className="mt-8 space-y-3">
            {DESTAQUES.map(({ icon: Icon, texto }, i) => (
              <li
                key={texto}
                className="fade-up flex items-center gap-3 text-sm text-primary-foreground/90"
                style={{ animationDelay: `${0.2 + i * 0.12}s` }}
              >
                <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-primary-foreground/15">
                  <Icon className="size-4" />
                </span>
                {texto}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs text-primary-foreground/60">
          © {new Date().getFullYear()} Conecta Solar — Monitoramento de usinas solares
        </p>
      </div>

      {/* Formulário */}
      <div className="relative flex items-center justify-center overflow-hidden px-5 py-12">
        {/* Cena animada do mobile */}
        <div className="pointer-events-none absolute inset-0 lg:hidden" aria-hidden>
          <div
            className="aurora absolute -top-28 left-1/2 h-72 w-[28rem] -translate-x-1/2 rounded-full blur-3xl"
            style={{
              background:
                "radial-gradient(closest-side, var(--color-primary), transparent 70%)",
              opacity: 0.25,
            }}
          />
          <div
            className="orb-drift-slow absolute -bottom-24 -right-16 size-72 rounded-full opacity-20 blur-3xl"
            style={{ background: "var(--color-chart-2)" }}
          />
          <div className="absolute inset-0 overflow-hidden">
            {[12, 34, 58, 76, 90].map((left, i) => (
              <span
                key={left}
                className="particle-rise absolute bottom-16 size-1 rounded-full bg-primary/40"
                style={{ left: `${left}%`, animationDelay: `${i * 1.8}s` }}
              />
            ))}
          </div>
          <div className="absolute inset-x-0 bottom-8 flex items-end justify-center gap-1.5 opacity-25">
            {[10, 18, 26, 16, 30, 22, 34, 20, 28].map((h, i) => (
              <span
                key={i}
                className="bar-breathe w-2 rounded-t-sm bg-primary"
                style={{ height: `${h}px`, animationDelay: `${i * 0.25}s` }}
              />
            ))}
          </div>
        </div>

        <div className="fade-up relative w-full max-w-sm">
          <div className="flex items-center gap-2.5 lg:hidden">
            <div className="relative grid size-10 place-items-center rounded-xl bg-primary text-primary-foreground">
              <span
                className="halo-pulse absolute inset-0 rounded-xl ring-1 ring-primary/60"
                aria-hidden
              />
              <span
                className="ring-expand absolute inset-0 rounded-xl ring-1 ring-primary/40"
                style={{ animationDelay: "1.5s" }}
                aria-hidden
              />
              <Sun className="size-5" />
            </div>
            <span className="font-display text-xl font-bold tracking-tight">Conecta Solar</span>
          </div>


          <h1 className="mt-8 font-display text-3xl font-bold tracking-tight lg:mt-0">
            Bem-vindo de volta
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Entre com seu e-mail para acessar o painel da sua usina.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <label className="block">
              <span className="text-xs font-semibold text-muted-foreground">E-mail</span>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-input bg-card px-3 focus-within:ring-2 focus-within:ring-ring">
                <Mail className="size-4 shrink-0 text-muted-foreground" />
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="voce@email.com"
                  className="w-full bg-transparent py-3 text-sm outline-none"
                />
              </div>
            </label>

            <label className="block">
              <span className="text-xs font-semibold text-muted-foreground">Senha</span>
              <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-input bg-card px-3 focus-within:ring-2 focus-within:ring-ring">
                <Lock className="size-4 shrink-0 text-muted-foreground" />
                <input
                  type="password"
                  autoComplete="current-password"
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-transparent py-3 text-sm outline-none"
                />
              </div>
            </label>

            {erro && (
              <p role="alert" className="text-xs font-medium text-destructive">
                {erro}
              </p>
            )}

            <button
              type="submit"
              disabled={carregando}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              {carregando ? "Entrando..." : "Entrar"}
              {!carregando && <ArrowRight className="size-4" />}
            </button>
          </form>

          <p className="mt-6 rounded-xl bg-muted p-3 text-xs text-muted-foreground">
            Acesso de demonstração: qualquer e-mail válido entra. A autenticação real
            com contas e senha será conectada em uma próxima etapa.
          </p>
        </div>
      </div>
    </div>
  );
}

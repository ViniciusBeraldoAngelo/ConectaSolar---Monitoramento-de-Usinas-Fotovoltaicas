import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { User, Moon, SunMedium, Check, Palette, LogOut, AlertTriangle } from "lucide-react";
import { AppSidebar } from "@/components/AppSidebar";
import { signOut } from "@/lib/auth";
import {
  loadSettings,
  saveSettings,
  applyTheme,
  type Settings,
} from "@/lib/solar-data";

export const Route = createFileRoute("/configuracoes")({
  head: () => ({
    meta: [
      { title: "Ajustes — Conecta Solar" },
      {
        name: "description",
        content: "Personalize nome, foto e tema do seu aplicativo de monitoramento solar.",
      },
      { property: "og:title", content: "Ajustes — Conecta Solar" },
      {
        property: "og:description",
        content: "Personalize seu perfil e o tema do aplicativo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

const DESTAQUES: { key: Settings["destaque"]; label: string; swatch: string }[] = [
  { key: "roxo", label: "Índigo", swatch: "oklch(0.546 0.215 277)" },
  { key: "azul", label: "Azul", swatch: "oklch(0.546 0.185 255)" },
  { key: "violeta", label: "Violeta", swatch: "oklch(0.52 0.235 295)" },
];

function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [salvo, setSalvo] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [confirmar, setConfirmar] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setSettings(loadSettings());
  }, []);

  useEffect(() => {
    if (!settings) return;
    saveSettings(settings);
    applyTheme(settings.tema, settings.destaque);
    window.dispatchEvent(new Event("solana-settings-changed"));
    setSalvo(true);
    const t = setTimeout(() => setSalvo(false), 1500);
    return () => clearTimeout(t);
  }, [settings]);

  if (!settings) {
    return (
      <div className="min-h-screen bg-background">
        <AppSidebar />
      </div>
    );
  }

  const update = (patch: Partial<Settings>) =>
    setSettings((s) => (s ? { ...s, ...patch } : s));

  const onFoto = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => update({ foto: String(reader.result) });
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="px-5 pt-8 pb-28 lg:pb-12 lg:pl-72 lg:pr-10">
        <div className="mx-auto max-w-3xl">
          <header className="fade-up flex items-end justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Ajustes</h1>
              <p className="mt-1 text-sm text-muted-foreground">
                Deixe o aplicativo com a sua cara.
              </p>
            </div>
            {salvo && (
              <span className="fade-up flex items-center gap-1.5 rounded-full bg-success/10 px-3 py-1 text-xs font-semibold text-success">
                <Check className="size-3.5" /> Salvo
              </span>
            )}
          </header>

          {/* Perfil */}
          <section className="fade-up mt-6 rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-semibold">Perfil</h2>
            <div className="mt-4 flex items-center gap-5">
              <button
                onClick={() => fileRef.current?.click()}
                className="group relative grid size-20 shrink-0 place-items-center overflow-hidden rounded-full bg-primary-soft text-primary ring-1 ring-border"
                aria-label="Alterar foto de perfil"
              >
                {settings.foto ? (
                  <img src={settings.foto} alt="Foto de perfil" className="size-full object-cover" />
                ) : (
                  <User className="size-8" />
                )}
                <span className="absolute inset-0 grid place-items-center bg-foreground/40 text-xs font-semibold text-background opacity-0 transition-opacity group-hover:opacity-100">
                  Trocar
                </span>
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => onFoto(e.target.files?.[0])}
              />
              <div className="flex-1 space-y-3">
                <label className="block text-xs font-medium text-muted-foreground">
                  Nome
                  <input
                    value={settings.nome}
                    onChange={(e) => update({ nome: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground focus:ring-2 focus:ring-ring focus:outline-none"
                  />
                </label>
                <label className="block text-xs font-medium text-muted-foreground">
                  Nome da usina
                  <input
                    value={settings.usina}
                    onChange={(e) => update({ usina: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground focus:ring-2 focus:ring-ring focus:outline-none"
                  />
                </label>
              </div>
            </div>
          </section>

          {/* Aparência */}
          <section className="fade-up mt-5 rounded-2xl border border-border bg-card p-6">
            <h2 className="flex items-center gap-2 text-sm font-semibold">
              <Palette className="size-4 text-primary" /> Aparência
            </h2>

            <p className="mt-4 text-xs font-medium text-muted-foreground">Modo</p>
            <div className="mt-2 grid grid-cols-2 gap-3">
              {(
                [
                  { key: "claro", label: "Claro", icon: SunMedium },
                  { key: "escuro", label: "Escuro", icon: Moon },
                ] as const
              ).map((m) => (
                <button
                  key={m.key}
                  onClick={() => update({ tema: m.key })}
                  aria-pressed={settings.tema === m.key}
                  className={`flex items-center justify-center gap-2 rounded-xl border py-3 text-sm font-semibold transition-all ${
                    settings.tema === m.key
                      ? "border-primary bg-primary-soft text-primary"
                      : "border-border text-muted-foreground hover:border-primary/40"
                  }`}
                >
                  <m.icon className="size-4" />
                  {m.label}
                </button>
              ))}
            </div>

            <p className="mt-5 text-xs font-medium text-muted-foreground">Cor de destaque</p>
            <div className="mt-2 flex gap-3">
              {DESTAQUES.map((d) => (
                <button
                  key={d.key}
                  onClick={() => update({ destaque: d.key })}
                  aria-pressed={settings.destaque === d.key}
                  aria-label={`Tema ${d.label}`}
                  className={`flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-medium transition-all ${
                    settings.destaque === d.key
                      ? "border-primary bg-primary-soft"
                      : "border-border hover:border-primary/40"
                  }`}
                >
                  <span
                    className="size-4 rounded-full"
                    style={{ backgroundColor: d.swatch }}
                  />
                  {d.label}
                  {settings.destaque === d.key && (
                    <Check className="size-3.5 text-primary" />
                  )}
                </button>
              ))}
            </div>
          </section>

          {/* Sessão */}
          <section className="fade-up mt-5 rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-semibold">Sessão</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Encerre o login para voltar à tela inicial de acesso.
            </p>
            <button
              onClick={() => setConfirmar(true)}
              className="mt-4 inline-flex items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-2.5 text-sm font-semibold text-destructive transition-colors hover:bg-destructive/15"
            >
              <LogOut className="size-4" /> Encerrar login
            </button>
          </section>
        </div>

        {confirmar && (
          <div
            className="fixed inset-0 z-50 grid place-items-center bg-foreground/40 px-5 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-labelledby="titulo-sair"
            onClick={() => setConfirmar(false)}
          >
            <div
              className="fade-up w-full max-w-sm rounded-2xl border border-border bg-card p-6 shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-destructive/10 text-destructive">
                  <AlertTriangle className="size-5" />
                </span>
                <div>
                  <h3 id="titulo-sair" className="text-base font-semibold">
                    Encerrar login?
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Você voltará para a tela de acesso e precisará entrar novamente.
                  </p>
                </div>
              </div>
              <div className="mt-6 flex gap-3">
                <button
                  onClick={() => setConfirmar(false)}
                  className="flex-1 rounded-xl border border-border px-4 py-2.5 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => {
                    signOut();
                    navigate({ to: "/login", replace: true });
                  }}
                  className="flex-1 rounded-xl bg-destructive px-4 py-2.5 text-sm font-semibold text-destructive-foreground transition-opacity hover:opacity-90"
                >
                  Sim, sair
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

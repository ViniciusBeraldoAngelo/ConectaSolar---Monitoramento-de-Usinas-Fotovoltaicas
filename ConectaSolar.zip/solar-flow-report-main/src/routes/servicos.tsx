import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Wrench,
  MessageCircle,
  Phone,
  Mail,
  Clock,
  MapPin,
  Check,
  Sparkles,
  FileText,
  Download,
} from "lucide-react";

import { AppSidebar } from "@/components/AppSidebar";
import {
  EMPRESA,
  SERVICOS,
  addSolicitacao,
  loadSolicitacoes,
  responderSolicitacao,
  aprovarProposta,
  confirmarServico,
  renegociarProposta,
  recusarProposta,
  cancelarSolicitacao,
  removerSolicitacao,
  formatBRLValor,
  formatDataCurta,
  whatsappLink,
  abrirAnexo,
  baixarAnexo,
  type ServicoKey,
  type Solicitacao,


  type SolicitacaoStatus,
} from "@/lib/company";

const STATUS_LABEL: Record<SolicitacaoStatus, string> = {
  enviada: "Enviada",
  proposta: "Proposta recebida",
  aprovada: "Aguardando confirmação da instaladora",
  confirmada: "Confirmada pela instaladora",
  renegociando: "Em negociação",
  recusada: "Oferta recusada",
  cancelada: "Cancelada",
};

export const Route = createFileRoute("/servicos")({
  head: () => ({
    meta: [
      { title: "Serviços e Contato — Conecta Solar" },
      {
        name: "description",
        content:
          "Solicite limpeza, manutenção, vistoria ou ampliação da sua usina solar e fale direto com a empresa instaladora.",
      },
      { property: "og:title", content: "Serviços e Contato — Conecta Solar" },
      {
        property: "og:description",
        content: "Agende manutenções e limpezas da sua usina solar em poucos toques.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ServicosPage,
});

const LABEL: Record<ServicoKey, string> = SERVICOS.reduce(
  (acc, s) => ({ ...acc, [s.key]: s.titulo }),
  {} as Record<ServicoKey, string>,
);

function ServicosPage() {
  const [servico, setServico] = useState<ServicoKey>("limpeza");
  const [mensagem, setMensagem] = useState("");
  const [preferencia, setPreferencia] = useState("");
  const [enviado, setEnviado] = useState(false);
  const [historico, setHistorico] = useState<Solicitacao[]>([]);
  const [renegociandoId, setRenegociandoId] = useState<string | null>(null);
  const [contraTexto, setContraTexto] = useState("");
  const [confirmarId, setConfirmarId] = useState<string | null>(null);

  useEffect(() => {
    const todas = loadSolicitacoes();
    setHistorico(todas);
    // A instaladora responde as solicitações pendentes.
    const pendentes = todas.filter(
      (s) => s.status === "enviada" || s.status === "renegociando",
    );
    const aguardando = todas.filter((s) => s.status === "aprovada");
    if (pendentes.length === 0 && aguardando.length === 0) return;
    const t = setTimeout(() => {
      let atual = loadSolicitacoes();
      pendentes.forEach((p) => {
        atual = responderSolicitacao(p.id);
      });
      aguardando.forEach((a) => {
        atual = confirmarServico(a.id);
      });
      setHistorico(atual);
    }, 2500);
    return () => clearTimeout(t);
  }, []);

  const agendarResposta = (id: string) => {
    setTimeout(() => setHistorico(responderSolicitacao(id)), 2500);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const nova = addSolicitacao({ servico, mensagem, preferencia });
    setHistorico(loadSolicitacoes());
    setMensagem("");
    setPreferencia("");
    setEnviado(true);
    agendarResposta(nova.id);
    setTimeout(() => setEnviado(false), 4000);
  };

  const aprovar = (id: string) => {
    setHistorico(aprovarProposta(id));
    setRenegociandoId(null);
    // A instaladora confirma o serviço e o contrato logo em seguida.
    setTimeout(() => setHistorico(confirmarServico(id)), 2500);
  };

  const enviarContraproposta = (id: string) => {
    setHistorico(renegociarProposta(id, contraTexto.trim() || "Gostaria de rever valor e data."));
    setRenegociandoId(null);
    setContraTexto("");
    agendarResposta(id);
  };

  const recusar = (id: string) => {
    setHistorico(recusarProposta(id));
    setRenegociandoId(null);
  };

  const desistir = (id: string) => {
    setHistorico(cancelarSolicitacao(id));
    setRenegociandoId(null);
    setConfirmarId(null);
  };

  const remover = (id: string) => {
    setHistorico(removerSolicitacao(id));
  };

  const textoWhats = `Olá, ${EMPRESA.nome}! Sou cliente Conecta Solar e gostaria de falar sobre: ${LABEL[servico]}.`;

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="px-5 pt-8 pb-28 lg:pb-12 lg:pl-72 lg:pr-10">
        <div className="mx-auto max-w-5xl">
          <header className="fade-up">
            <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
              Suporte da sua instaladora
            </p>
            <h1 className="mt-1 text-3xl font-bold tracking-tight">Serviços e contato</h1>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">
              Agende limpeza, manutenção ou peça um orçamento direto com a empresa
              responsável pelo seu sistema solar.
            </p>
          </header>

          {/* Contato direto */}
          <section className="fade-up mt-6 rounded-2xl border border-border bg-card p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-xs font-medium text-muted-foreground">Sua instaladora</p>
                <h2 className="font-display text-xl font-bold tracking-tight">
                  {EMPRESA.nome}
                </h2>
                <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1.5 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="size-3.5" /> {EMPRESA.horario}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <MapPin className="size-3.5" /> {EMPRESA.cidade}
                  </span>
                </div>
              </div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-success/10 px-2.5 py-1 text-xs font-semibold text-success">
                <Sparkles className="size-3.5" /> Atendimento ativo
              </span>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <a
                href={whatsappLink(textoWhats)}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
              >
                <MessageCircle className="size-4" /> WhatsApp
              </a>
              <a
                href={`tel:${EMPRESA.telefone.replace(/\s/g, "")}`}
                className="flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-sm font-semibold transition-colors hover:bg-muted"
              >
                <Phone className="size-4 text-primary" /> Ligar
              </a>
              <a
                href={`mailto:${EMPRESA.email}?subject=${encodeURIComponent(`Conecta Solar — ${LABEL[servico]}`)}`}
                className="flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-sm font-semibold transition-colors hover:bg-muted"
              >
                <Mail className="size-4 text-primary" /> E-mail
              </a>
            </div>
          </section>

          {/* Formulário de solicitação */}
          <section className="fade-up mt-5 grid gap-5 lg:grid-cols-3">
            <form
              onSubmit={submit}
              className="rounded-2xl border border-border bg-card p-6 lg:col-span-2"
            >
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <Wrench className="size-4 text-primary" /> Abrir solicitação
              </h2>

              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {SERVICOS.map((s) => (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setServico(s.key)}
                    aria-pressed={servico === s.key}
                    className={`rounded-xl border p-3 text-left transition-colors ${
                      servico === s.key
                        ? "border-primary bg-primary-soft"
                        : "border-border hover:bg-muted"
                    }`}
                  >
                    <span className="flex items-center justify-between text-sm font-semibold">
                      {s.titulo}
                      {servico === s.key && <Check className="size-4 text-primary" />}
                    </span>
                    <span className="mt-0.5 block text-xs text-muted-foreground">
                      {s.descricao}
                    </span>
                  </button>
                ))}
              </div>

              <label className="mt-4 block">
                <span className="text-xs font-semibold text-muted-foreground">
                  Melhor dia / horário
                </span>
                <input
                  value={preferencia}
                  onChange={(e) => setPreferencia(e.target.value)}
                  placeholder="Ex.: terça pela manhã"
                  className="mt-1.5 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </label>

              <label className="mt-4 block">
                <span className="text-xs font-semibold text-muted-foreground">
                  Detalhes
                </span>
                <textarea
                  value={mensagem}
                  onChange={(e) => setMensagem(e.target.value)}
                  rows={4}
                  placeholder="Conte o que está acontecendo ou o que você precisa."
                  className="mt-1.5 w-full resize-none rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </label>

              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  type="submit"
                  className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                >
                  Enviar solicitação
                </button>
                {enviado && (
                  <span
                    role="status"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-success"
                  >
                    <Check className="size-4" /> Solicitação registrada
                  </span>
                )}
              </div>
            </form>

            {/* Histórico + propostas */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <h2 className="text-sm font-semibold">Minhas solicitações</h2>
              {historico.length === 0 ? (
                <p className="mt-3 text-xs text-muted-foreground">
                  Nenhuma solicitação ainda. Ao enviar, ela aparece aqui com a
                  resposta da instaladora — valor, data e aprovação.
                </p>
              ) : (
                <ul className="mt-3 space-y-3">
                  {historico.slice(0, 6).map((s) => (
                    <li key={s.id} className="rounded-xl bg-muted p-3">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-semibold">{LABEL[s.servico]}</p>
                        <span
                          className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                            s.status === "confirmada"
                              ? "bg-success/10 text-success"
                              : s.status === "aprovada"
                                ? "bg-primary-soft text-primary"
                                : s.status === "proposta"
                                ? "bg-primary-soft text-primary"
                                : s.status === "recusada"
                                  ? "bg-destructive/10 text-destructive"
                                  : "bg-background text-muted-foreground"
                          }`}
                        >
                          {STATUS_LABEL[s.status]}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {new Date(s.criadoEm).toLocaleDateString("pt-BR", {
                          day: "2-digit",
                          month: "short",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                        {s.preferencia ? ` • ${s.preferencia}` : ""}
                      </p>
                      {s.mensagem && (
                        <p className="mt-1.5 line-clamp-3 text-xs text-muted-foreground">
                          {s.mensagem}
                        </p>
                      )}

                      {s.contraproposta && (
                        <p className="mt-2 rounded-lg bg-background p-2 text-xs text-muted-foreground">
                          <span className="font-semibold text-foreground">
                            Sua contraproposta:{" "}
                          </span>
                          {s.contraproposta}
                        </p>
                      )}

                      {s.status === "enviada" || s.status === "renegociando" ? (
                        <div className="mt-2">
                          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Clock className="size-3.5" /> Aguardando resposta de{" "}
                            {EMPRESA.nome}…
                          </p>
                          <button
                            type="button"
                            onClick={() => setConfirmarId(s.id)}
                            className="mt-2 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted"
                          >
                            Desistir da solicitação
                          </button>
                        </div>
                      ) : null}

                      {s.status === "cancelada" && (
                        <button
                          type="button"
                          onClick={() => remover(s.id)}
                          className="mt-2 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted"
                        >
                          Remover do histórico
                        </button>
                      )}

                      {confirmarId === s.id && (
                        <div className="mt-2 rounded-lg border border-destructive/40 bg-background p-2.5">
                          <p className="text-xs font-semibold">
                            Desistir desta solicitação?
                          </p>
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            A instaladora será avisada e o atendimento será encerrado.
                          </p>
                          <div className="mt-2 flex gap-2">
                            <button
                              type="button"
                              onClick={() => desistir(s.id)}
                              className="rounded-lg bg-destructive px-3 py-1.5 text-xs font-semibold text-destructive-foreground transition-opacity hover:opacity-90"
                            >
                              Sim, desistir
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmarId(null)}
                              className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold transition-colors hover:bg-muted"
                            >
                              Manter
                            </button>
                          </div>
                        </div>
                      )}

                      {s.proposta && s.status !== "renegociando" && (
                        <div className="mt-2 rounded-xl border border-primary/30 bg-background p-3">
                          <p className="text-[11px] font-semibold text-primary">
                            Proposta da instaladora
                            {s.proposta.rodada > 1
                              ? ` • revisão ${s.proposta.rodada}`
                              : ""}
                          </p>
                          <div className="mt-1.5 flex items-baseline gap-1.5">
                            <span className="text-lg font-bold tracking-tight">
                              {formatBRLValor(s.proposta.valor)}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {s.servico === "expansao" ? "estimado" : "por visita"}
                            </span>
                          </div>
                          <p className="mt-1 text-xs text-muted-foreground">
                            Execução em {formatDataCurta(s.proposta.dataExecucao)} •{" "}
                            {s.proposta.janela}
                          </p>
                          <p className="mt-1 text-xs text-muted-foreground">
                            {s.proposta.observacao}
                          </p>

                          {s.proposta.anexos && s.proposta.anexos.length > 0 && (
                            <div className="mt-2.5 space-y-1.5">
                              <p className="text-[11px] font-semibold text-muted-foreground">
                                Anexos enviados pela instaladora
                              </p>
                              {s.proposta.anexos.map((a) => (
                                <div
                                  key={a.nome}
                                  className="flex items-center gap-2 rounded-lg border border-border bg-muted/40 px-2.5 py-2"
                                >
                                  <FileText className="size-4 shrink-0 text-primary" />
                                  <div className="min-w-0 flex-1">
                                    <p className="truncate text-xs font-medium">
                                      {a.titulo}
                                    </p>
                                    <p className="truncate text-[11px] text-muted-foreground">
                                      PDF • {a.tamanhoKb} KB
                                    </p>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => abrirAnexo(a)}
                                    className="rounded-md border border-border px-2 py-1 text-[11px] font-semibold transition-colors hover:bg-muted"
                                  >
                                    Visualizar
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => baixarAnexo(a)}
                                    aria-label={`Baixar ${a.titulo}`}
                                    className="rounded-md border border-border p-1 transition-colors hover:bg-muted"
                                  >
                                    <Download className="size-3.5" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}


                          {renegociandoId === s.id ? (
                            <div className="mt-2">
                              <textarea
                                value={contraTexto}
                                onChange={(e) => setContraTexto(e.target.value)}
                                rows={3}
                                placeholder="Ex.: consigo pagar até R$ 320 e prefiro sábado."
                                className="w-full resize-none rounded-lg border border-input bg-background px-2.5 py-2 text-xs outline-none focus:ring-2 focus:ring-ring"
                              />
                              <div className="mt-2 flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => enviarContraproposta(s.id)}
                                  className="rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                                >
                                  Enviar
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setRenegociandoId(null)}
                                  className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold transition-colors hover:bg-muted"
                                >
                                  Cancelar
                                </button>
                              </div>
                            </div>
                          ) : s.status === "cancelada" ? (
                            <p className="mt-2 text-xs font-semibold text-muted-foreground">
                              Solicitação cancelada pelo cliente.
                            </p>
                          ) : s.status === "recusada" ? (
                            <div className="mt-2">
                              <p className="text-xs font-semibold text-destructive">
                                Oferta recusada.
                              </p>
                              <div className="mt-2 flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRenegociandoId(s.id);
                                    setContraTexto("");
                                  }}
                                  className="flex-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold transition-colors hover:bg-muted"
                                >
                                  Reabrir negociação
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmarId(s.id)}
                                  className="flex-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-destructive transition-colors hover:bg-muted"
                                >
                                  Desistir
                                </button>
                              </div>
                            </div>
                          ) : s.status === "aprovada" ? (
                            <div className="mt-2 rounded-lg border border-border bg-background p-2.5">
                              <p className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                                <Check className="size-3.5" /> Você aprovou a
                                proposta
                              </p>
                              <p className="mt-1 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                                <span className="size-1.5 animate-pulse rounded-full bg-primary" />
                                Aguardando {EMPRESA.nome} confirmar o serviço e o
                                contrato…
                              </p>
                            </div>
                          ) : s.status === "confirmada" ? (
                            <div className="mt-2 rounded-lg border border-success/30 bg-success/5 p-2.5">
                              <p className="inline-flex items-center gap-1.5 text-xs font-semibold text-success">
                                <Check className="size-3.5" /> Serviço e contrato
                                confirmados pela instaladora
                              </p>
                              {s.confirmadoEm && (
                                <p className="mt-1 text-[11px] text-muted-foreground">
                                  Confirmado em{" "}
                                  {new Date(s.confirmadoEm).toLocaleDateString(
                                    "pt-BR",
                                    {
                                      day: "2-digit",
                                      month: "short",
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    },
                                  )}
                                  {s.proposta &&
                                    ` — execução em ${formatDataCurta(s.proposta.dataExecucao)}`}
                                </p>
                              )}
                            </div>
                          ) : (
                            <div className="mt-2.5 space-y-2">
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => aprovar(s.id)}
                                  className="flex-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                                >
                                  Aprovar
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRenegociandoId(s.id);
                                    setContraTexto("");
                                  }}
                                  className="flex-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold transition-colors hover:bg-muted"
                                >
                                  Negociar
                                </button>
                              </div>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => recusar(s.id)}
                                  className="flex-1 rounded-lg border border-destructive/40 px-3 py-1.5 text-xs font-semibold text-destructive transition-colors hover:bg-destructive/10"
                                >
                                  Recusar oferta
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setConfirmarId(s.id)}
                                  className="flex-1 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted"
                                >
                                  Desistir
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

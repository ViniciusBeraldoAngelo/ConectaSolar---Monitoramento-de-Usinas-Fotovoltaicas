import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Zap, PiggyBank, Leaf, Gauge, TrendingUp } from "lucide-react";
import { EnergyChart } from "@/components/EnergyChart";
import { KpiCard } from "@/components/KpiCard";
import { AppSidebar } from "@/components/AppSidebar";
import {
  getGenerationData,
  formatKwh,
  formatBRL,
  type PeriodKey,
} from "@/lib/solar-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Geração de Energia — Conecta Solar" },
      {
        name: "description",
        content:
          "Monitore a geração da sua usina solar por dia, semana, mês ou ano com gráficos limpos e comparativo de consumo.",
      },
      { property: "og:title", content: "Geração de Energia — Conecta Solar" },
      {
        property: "og:description",
        content: "Monitoramento de usinas solares com visualização limpa e fácil.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GenerationPage,
});

const PERIODS: { key: PeriodKey; label: string }[] = [
  { key: "dia", label: "Dia" },
  { key: "semana", label: "Semana" },
  { key: "mes", label: "Mês" },
  { key: "ano", label: "Ano" },
  { key: "periodo", label: "Período" },
];

const PERIOD_COPY: Record<PeriodKey, { titulo: string; unidade: string }> = {
  dia: { titulo: "Produção hoje", unidade: "kWh" },
  semana: { titulo: "Produção na semana", unidade: "kWh" },
  mes: { titulo: "Produção no mês", unidade: "kWh" },
  ano: { titulo: "Produção no ano", unidade: "kWh" },
  periodo: { titulo: "Produção no período", unidade: "kWh" },
};

function GenerationPage() {
  const [period, setPeriod] = useState<PeriodKey>("dia");
  const [de, setDe] = useState("2026-08-20");
  const [ate, setAte] = useState("2026-08-27");
  const [mostrarConsumo, setMostrarConsumo] = useState(false);

  const data = useMemo(() => getGenerationData(period), [period, de, ate]);
  const consumo = useMemo(
    () =>
      mostrarConsumo
        ? data.map((d) => ({ label: d.label, kwh: +(d.kwh * (0.75 + (d.kwh % 3) / 10)).toFixed(1) }))
        : undefined,
    [data, mostrarConsumo],
  );

  // Rótulo do intervalo visualizado (calculado após a hidratação para evitar divergência SSR)
  const [hoje, setHoje] = useState<Date | null>(null);
  useEffect(() => setHoje(new Date()), []);

  const intervaloLabel = useMemo(() => {
    if (!hoje) return "Carregando período…";
    const fmt = (d: Date, o: Intl.DateTimeFormatOptions) =>
      d.toLocaleDateString("pt-BR", o);
    if (period === "dia") {
      return fmt(hoje, { day: "2-digit", month: "long", year: "numeric" });
    }
    if (period === "semana") {
      const ini = new Date(hoje);
      ini.setDate(hoje.getDate() - 6);
      return `Semana de ${fmt(ini, { day: "2-digit", month: "short" })} a ${fmt(hoje, { day: "2-digit", month: "short", year: "numeric" })}`;
    }
    if (period === "mes") {
      const m = fmt(hoje, { month: "long", year: "numeric" });
      return m.charAt(0).toUpperCase() + m.slice(1);
    }
    if (period === "ano") return `Ano de ${hoje.getFullYear()}`;
    const p = (s: string) => {
      const [y, m, d] = s.split("-");
      return `${d}/${m}/${y}`;
    };
    return `De ${p(de)} até ${p(ate)}`;
  }, [period, de, ate, hoje]);

  const total = data.reduce((s, d) => s + d.kwh, 0);
  const economia = total * 0.92;
  const co2 = total * 0.0817;
  const pr = 94.2;

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="px-5 pt-8 pb-28 lg:pb-12 lg:pl-72 lg:pr-10">
        <div className="mx-auto max-w-5xl">
          {/* Cabeçalho + filtro */}
          <header className="fade-up flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
                Usina online • atualizado agora
              </p>
              <h1 className="mt-1 text-3xl font-bold tracking-tight">
                Geração de energia
              </h1>
            </div>
            <div
              className="flex w-fit rounded-xl border border-border bg-card p-1"
              role="tablist"
              aria-label="Selecionar período"
            >
              {PERIODS.map((p) => (
                <button
                  key={p.key}
                  role="tab"
                  aria-selected={period === p.key}
                  onClick={() => setPeriod(p.key)}
                  className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
                    period === p.key
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </header>

          {/* Seletor de período personalizado */}
          {period === "periodo" && (
            <div className="fade-up mt-5 flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card p-4 text-sm">
              <label className="flex items-center gap-2">
                <span className="text-xs font-medium text-muted-foreground">De</span>
                <input
                  type="date"
                  value={de}
                  onChange={(e) => setDe(e.target.value)}
                  className="rounded-lg border border-input bg-background px-3 py-1.5 text-sm focus:ring-2 focus:ring-ring focus:outline-none"
                />
              </label>
              <label className="flex items-center gap-2">
                <span className="text-xs font-medium text-muted-foreground">Até</span>
                <input
                  type="date"
                  value={ate}
                  onChange={(e) => setAte(e.target.value)}
                  className="rounded-lg border border-input bg-background px-3 py-1.5 text-sm focus:ring-2 focus:ring-ring focus:outline-none"
                />
              </label>
              <span className="text-xs text-muted-foreground">
                Exibindo curva horária média do intervalo selecionado.
              </span>
            </div>
          )}

          {/* Número herói + gráfico */}
          <section className="fade-up mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
            <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 lg:col-span-2">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-medium text-muted-foreground">
                    {PERIOD_COPY[period].titulo}
                  </span>
                  <div className="mt-1 flex items-baseline gap-2">
                    <span className="font-display text-5xl font-bold tracking-tight">
                      {formatKwh(total)}
                    </span>
                    <span className="text-lg text-muted-foreground">
                      {PERIOD_COPY[period].unidade}
                    </span>
                  </div>
                  <p className="mt-2 text-xs font-semibold text-primary">
                    {intervaloLabel}
                  </p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-success/10 px-2.5 py-1 text-xs font-semibold text-success">
                  <TrendingUp className="size-3.5" />
                  +12% vs anterior
                </span>
              </div>

              <div className="mt-6">
                <EnergyChart data={data} compareData={consumo} />
              </div>

              <label className="mt-5 flex w-fit cursor-pointer items-center gap-2 text-sm text-muted-foreground">
                <input
                  type="checkbox"
                  checked={mostrarConsumo}
                  onChange={(e) => setMostrarConsumo(e.target.checked)}
                  className="size-4 accent-[var(--color-primary)]"
                />
                Comparar com consumo (faturas)
              </label>
            </div>

            {/* KPIs */}
            <div className="flex flex-col gap-4">
              <KpiCard
                label="Potência instantânea"
                value="5,2 kW"
                hint="Pico às 12h40"
                icon={Zap}
              />
              <KpiCard
                label="Economia no período"
                value={formatBRL(economia)}
                hint="Tarifa média R$ 0,92/kWh"
                icon={PiggyBank}
                dark
              />
              <KpiCard
                label="CO₂ evitado"
                value={`${formatKwh(co2)} kg`}
                hint="≈ 4 árvores plantadas"
                icon={Leaf}
              />
              <KpiCard
                label="Performance ratio"
                value={`${pr.toLocaleString("pt-BR")}%`}
                hint="Inversor estável"
                icon={Gauge}
              />
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

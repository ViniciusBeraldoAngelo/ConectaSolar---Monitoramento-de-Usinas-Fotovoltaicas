import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Sun, FileText, BarChart3, Settings2, User, Wrench, LogOut } from "lucide-react";
import { useEffect, useState } from "react";
import { loadSettings, type Settings } from "@/lib/solar-data";
import { signOut } from "@/lib/auth";

const NAV = [
  { to: "/", label: "Geração", icon: Sun },
  { to: "/faturas", label: "Faturas", icon: FileText },
  { to: "/relatorios", label: "Relatórios", icon: BarChart3 },
  { to: "/servicos", label: "Serviços", icon: Wrench },
  { to: "/configuracoes", label: "Ajustes", icon: Settings2 },
] as const;


export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const [settings, setSettings] = useState<Settings | null>(null);


  useEffect(() => {
    setSettings(loadSettings());
    const onStorage = () => setSettings(loadSettings());
    window.addEventListener("solana-settings-changed", onStorage);
    return () => window.removeEventListener("solana-settings-changed", onStorage);
  }, []);

  const isActive = (to: string) =>
    to === "/" ? pathname === "/" : pathname.startsWith(to);

  return (
    <>
      {/* Sidebar desktop */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-border bg-card lg:flex">
        <div className="flex items-center gap-2.5 px-6 pt-7 pb-8">
          <div className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground">
            <Sun className="size-4.5" />
          </div>
          <span className="font-display text-lg font-bold tracking-tight">
            Conecta Solar
          </span>
        </div>

        <nav className="flex-1 space-y-1 px-3">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive(to)
                  ? "bg-primary-soft text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <Icon className="size-4" />
              {label}
            </Link>
          ))}
        </nav>

        <div className="space-y-1 border-t border-border p-4">
          <Link to="/configuracoes" className="flex items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-muted transition-colors">
            {settings?.foto ? (
              <img
                src={settings.foto}
                alt={`Foto de ${settings.nome}`}
                className="size-9 rounded-full object-cover ring-1 ring-border"
              />
            ) : (
              <div className="grid size-9 place-items-center rounded-full bg-primary-soft text-primary">
                <User className="size-4" />
              </div>
            )}
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">
                {settings?.nome ?? "Usuário"}
              </p>
              <p className="truncate text-xs text-muted-foreground">
                {settings?.usina ?? "Minha usina"}
              </p>
            </div>
          </Link>
          <button
            onClick={() => {
              signOut();
              navigate({ to: "/login", replace: true });
            }}
            className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <LogOut className="size-4" /> Sair da conta
          </button>
        </div>

      </aside>

      {/* Navegação inferior mobile */}
      <nav className="fixed inset-x-4 bottom-4 z-40 flex justify-around rounded-2xl border border-border bg-card/90 p-1.5 shadow-lg backdrop-blur-xl lg:hidden">
        {NAV.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className={`flex flex-col items-center gap-1 rounded-xl px-2.5 py-2 text-[10px] font-medium transition-colors ${
              isActive(to) ? "bg-primary text-primary-foreground" : "text-muted-foreground"
            }`}
          >
            <Icon className="size-4" />
            {label}
          </Link>
        ))}
      </nav>
    </>
  );
}

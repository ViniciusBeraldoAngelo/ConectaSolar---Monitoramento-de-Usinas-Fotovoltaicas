import { useMemo, useState } from "react";
import { formatKwh, type EnergyPoint } from "@/lib/solar-data";

interface Props {
  data: EnergyPoint[];
  compareData?: EnergyPoint[] | undefined;
  compareLabel?: string;
}

/** Arredonda o topo do eixo para um passo "redondo" (1, 2, 5, 10, 20, 50...). */
function buildTicks(max: number, count = 4) {
  const raw = max / count;
  const mag = Math.pow(10, Math.floor(Math.log10(raw || 1)));
  const norm = raw / mag;
  const step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
  const top = step * count;
  return { top, ticks: Array.from({ length: count + 1 }, (_, i) => step * i).reverse() };
}

export function EnergyChart({ data, compareData }: Props) {
  const [hovered, setHovered] = useState<number | null>(null);

  const rawMax = useMemo(
    () => Math.max(...data.map((d) => d.kwh), ...(compareData?.map((d) => d.kwh) ?? []), 1),
    [data, compareData],
  );
  const { top: max, ticks } = useMemo(() => buildTicks(rawMax), [rawMax]);

  const total = data.reduce((s, d) => s + d.kwh, 0);

  return (
    <div>
      <div className="flex gap-3">
        {/* Eixo Y */}
        <div
          className="flex h-56 w-10 shrink-0 flex-col justify-between text-right text-[10px] font-medium text-muted-foreground sm:h-64"
          aria-hidden
        >
          {ticks.map((t) => (
            <span key={t} className="-translate-y-1/2 leading-none first:translate-y-0 last:-translate-y-full">
              {formatKwh(t)}
            </span>
          ))}
        </div>

        <div className="relative flex-1">
          {/* Linhas de grade */}
          <div className="pointer-events-none absolute inset-0 flex flex-col justify-between" aria-hidden>
            {ticks.map((t) => (
              <div key={t} className="h-px w-full bg-border/60" />
            ))}
          </div>

          <div
            className="relative flex h-56 items-end gap-1.5 sm:h-64"
            role="img"
            aria-label={`Gráfico de geração de energia, total ${formatKwh(total)} kWh`}
          >
            {data.map((d, i) => {
              const h = (d.kwh / max) * 100;
              const cmp = compareData?.[i];
              const isHovered = hovered === i;
              return (
                <div
                  key={`${d.label}-${i}`}
                  className="group relative flex h-full flex-1 items-end justify-center gap-0.5"
                  onMouseEnter={() => setHovered(i)}
                  onMouseLeave={() => setHovered(null)}
                >
                  {cmp !== undefined && (
                    <div
                      className="bar-grow w-1/3 rounded-t-sm bg-muted-foreground/25"
                      style={{ height: `${(cmp.kwh / max) * 100}%`, animationDelay: `${i * 20}ms` }}
                    />
                  )}
                  <div
                    className={`w-full rounded-t-sm transition-colors ${
                      isHovered ? "bg-primary" : cmp !== undefined ? "bg-primary" : "bg-primary/85"
                    }`}
                    style={{ height: `${h}%` }}
                  />
                  {isHovered && (
                    <div className="pointer-events-none absolute -top-2 z-10 -translate-y-full rounded-lg border border-border bg-popover px-2.5 py-1.5 text-center shadow-md">
                      <p className="text-[10px] font-medium text-muted-foreground">{d.label}</p>
                      <p className="text-xs font-bold text-popover-foreground">{formatKwh(d.kwh)} kWh</p>
                      {cmp !== undefined && (
                        <p className="text-[10px] text-muted-foreground">
                          Consumo: {formatKwh(cmp.kwh)} kWh
                        </p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-3 flex justify-between border-t border-border pt-3 text-[10px] font-medium text-muted-foreground">
            <span>{data[0]?.label}</span>
            <span>{data[Math.floor(data.length / 2)]?.label}</span>
            <span>{data[data.length - 1]?.label}</span>
          </div>
        </div>
      </div>
      <p className="mt-2 text-[10px] font-medium tracking-wide text-muted-foreground uppercase">
        Valores em kWh
      </p>
    </div>
  );
}

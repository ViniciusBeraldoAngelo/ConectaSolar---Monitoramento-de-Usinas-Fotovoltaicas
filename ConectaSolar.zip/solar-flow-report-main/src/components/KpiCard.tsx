import type { LucideIcon } from "lucide-react";

interface Props {
  label: string;
  value: string;
  hint?: string;
  icon: LucideIcon;
  dark?: boolean;
}

export function KpiCard({ label, value, hint, icon: Icon, dark }: Props) {
  return (
    <div
      className={`fade-up rounded-2xl border p-5 ${
        dark
          ? "border-transparent bg-primary text-primary-foreground"
          : "border-border bg-card"
      }`}
    >
      <div className="flex items-center justify-between">
        <span
          className={`text-xs font-medium ${dark ? "text-primary-foreground/70" : "text-muted-foreground"}`}
        >
          {label}
        </span>
        <Icon className={`size-4 ${dark ? "text-primary-foreground/70" : "text-primary"}`} />
      </div>
      <p className="mt-3 font-display text-2xl font-bold tracking-tight">{value}</p>
      {hint && (
        <p className={`mt-1 text-xs ${dark ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
          {hint}
        </p>
      )}
    </div>
  );
}

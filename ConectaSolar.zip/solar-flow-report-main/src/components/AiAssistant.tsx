import { useEffect, useRef, useState } from "react";
import { Sparkles, X, SendHorizonal } from "lucide-react";

interface Msg {
  de: "ia" | "eu";
  texto: string;
}

const SUGESTOES = [
  "Por que minha geração caiu?",
  "Como leio o gráfico de geração?",
  "Quando devo limpar os painéis?",
  "O que é performance ratio?",
];

const RESPOSTAS: { chaves: string[]; texto: string }[] = [
  {
    chaves: ["caiu", "queda", "baixa", "pouca", "diminuiu"],
    texto:
      "Quedas de geração normalmente têm 3 causas: dias nublados/chuva, sujeira nos módulos ou um alerta no inversor. Compare o dia com a mesma semana do mês anterior na aba Geração. Se a queda passar de 20% em dias de sol, vale abrir uma solicitação de vistoria na aba Serviços.",
  },
  {
    chaves: ["gráfico", "grafico", "ler", "curva", "período", "periodo"],
    texto:
      "O gráfico mostra a energia gerada (kWh) no período escolhido. Em 'Dia' você vê a curva hora a hora, com o pico perto do meio-dia. Ative 'Comparar com consumo' para sobrepor o consumo vindo das faturas e enxergar quanto da sua energia é autoconsumida.",
  },
  {
    chaves: ["limpeza", "limpar", "sujeira", "manutenção", "manutencao"],
    texto:
      "A recomendação geral é limpeza a cada 6 meses, ou antes disso em regiões com muita poeira, obra por perto ou árvores. Na aba Serviços você agenda limpeza direto com a empresa que instalou o sistema, por formulário ou WhatsApp.",
  },
  {
    chaves: ["performance", "pr", "ratio"],
    texto:
      "Performance ratio (PR) compara o que a usina realmente gerou com o que ela poderia gerar na irradiação medida. Acima de 80% é considerado saudável; a sua está em torno de 94%, o que indica inversor e módulos operando bem.",
  },
  {
    chaves: ["fatura", "conta", "boleto", "concessionária", "concessionaria"],
    texto:
      "Na aba Faturas você acompanha cada fatura da concessionária, com consumo em kWh, valor, vencimento e status (paga, pendente ou vencida). Abra uma fatura para ver os detalhes e o comparativo com a geração do mês.",
  },
  {
    chaves: ["relatório", "relatorio", "exportar", "pdf"],
    texto:
      "Em Relatórios você escolhe o período e gera um resumo de geração e consumo, útil para enviar ao contador, à empresa instaladora ou guardar como histórico.",
  },
  {
    chaves: ["economia", "economizei", "dinheiro", "tarifa"],
    texto:
      "A economia é calculada multiplicando a energia gerada pela tarifa média da sua concessionária (hoje R$ 0,92/kWh na demonstração). Você vê o valor do período no cartão 'Economia' da tela de Geração.",
  },
];

function responder(pergunta: string) {
  const q = pergunta.toLowerCase();
  const hit = RESPOSTAS.find((r) => r.chaves.some((c) => q.includes(c)));
  if (hit) return hit.texto;
  return "Ainda estou aprendendo sobre esse assunto. Posso ajudar com geração de energia, faturas, relatórios, economia, limpeza e manutenção da usina. Se preferir falar com uma pessoa, use a aba Serviços para contatar a empresa instaladora.";
}

export function AiAssistant() {
  const [aberto, setAberto] = useState(false);
  const [texto, setTexto] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      de: "ia",
      texto:
        "Olá! Sou a assistente do Conecta Solar. Posso explicar sua geração, faturas e cuidados com a usina. O que você quer saber?",
    },
  ]);
  const fimRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, aberto]);

  const enviar = (pergunta: string) => {
    const p = pergunta.trim();
    if (!p) return;
    setTexto("");
    setMsgs((m) => [...m, { de: "eu", texto: p }]);
    setTimeout(
      () => setMsgs((m) => [...m, { de: "ia", texto: responder(p) }]),
      450,
    );
  };

  return (
    <>
      {aberto && (
        <div
          role="dialog"
          aria-label="Assistente de IA"
          className="fade-up fixed inset-x-4 bottom-24 z-50 flex max-h-[70vh] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl sm:inset-x-auto sm:right-6 sm:bottom-24 sm:w-96 lg:bottom-24"
        >
          <header className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-2.5">
              <span className="grid size-8 place-items-center rounded-lg bg-primary-soft text-primary">
                <Sparkles className="size-4" />
              </span>
              <div>
                <p className="text-sm font-semibold leading-tight">Assistente Conecta Solar</p>
                <p className="text-[11px] text-muted-foreground">Tire dúvidas sobre sua usina</p>
              </div>
            </div>
            <button
              onClick={() => setAberto(false)}
              aria-label="Fechar assistente"
              className="grid size-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted"
            >
              <X className="size-4" />
            </button>
          </header>

          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {msgs.map((m, i) => (
              <div
                key={i}
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                  m.de === "eu"
                    ? "ml-auto bg-primary text-primary-foreground"
                    : "bg-muted text-foreground"
                }`}
              >
                {m.texto}
              </div>
            ))}

            {msgs.length <= 1 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {SUGESTOES.map((s) => (
                  <button
                    key={s}
                    onClick={() => enviar(s)}
                    className="rounded-full border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
            <div ref={fimRef} />
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              enviar(texto);
            }}
            className="flex items-center gap-2 border-t border-border p-3"
          >
            <input
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
              placeholder="Escreva sua dúvida..."
              aria-label="Sua dúvida"
              className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              type="submit"
              aria-label="Enviar"
              className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground transition-opacity hover:opacity-90"
            >
              <SendHorizonal className="size-4" />
            </button>
          </form>
        </div>
      )}

      <button
        onClick={() => setAberto((v) => !v)}
        aria-label="Abrir assistente de IA"
        className="fixed bottom-24 right-5 z-50 flex items-center gap-2 rounded-full bg-primary px-4 py-3.5 text-sm font-semibold text-primary-foreground shadow-xl transition-transform hover:scale-105 lg:bottom-6 lg:right-8"
      >
        <Sparkles className="size-4" />
        <span className="hidden sm:inline">Dúvidas? Pergunte à IA</span>
      </button>
    </>
  );
}

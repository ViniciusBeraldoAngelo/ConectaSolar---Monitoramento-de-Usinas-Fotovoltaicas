// Dados da empresa integradora responsável pelo sistema solar.

export const EMPRESA = {
  nome: "SolTec Energia Solar",
  responsavel: "Equipe de Atendimento",
  telefone: "+55 11 4002-8922",
  whatsapp: "5511940028922",
  email: "atendimento@soltecenergia.com.br",
  horario: "Seg a Sex, 8h às 18h",
  cidade: "São Paulo — SP",
};

export type ServicoKey =
  | "limpeza"
  | "manutencao"
  | "vistoria"
  | "expansao"
  | "duvida";

export const SERVICOS: { key: ServicoKey; titulo: string; descricao: string }[] = [
  { key: "limpeza", titulo: "Limpeza dos módulos", descricao: "Recomendada a cada 6 meses" },
  { key: "manutencao", titulo: "Manutenção corretiva", descricao: "Queda de geração, inversor com alerta" },
  { key: "vistoria", titulo: "Vistoria preventiva", descricao: "Checagem elétrica e estrutural" },
  { key: "expansao", titulo: "Ampliar a usina", descricao: "Orçamento para novos módulos" },
  { key: "duvida", titulo: "Outro assunto", descricao: "Fale com um especialista" },
];

export type SolicitacaoStatus =
  | "enviada"
  | "proposta"
  | "aprovada"
  | "confirmada"
  | "renegociando"
  | "recusada"
  | "cancelada";

export interface Anexo {
  nome: string;
  titulo: string;
  paginas: string[];
  tamanhoKb: number;
}

export interface Proposta {
  valor: number;
  dataExecucao: string; // ISO date (yyyy-mm-dd)
  janela: string;
  observacao: string;
  respondidoEm: string;
  rodada: number;
  anexos?: Anexo[];
}


export interface Solicitacao {
  id: string;
  servico: ServicoKey;
  mensagem: string;
  preferencia: string;
  criadoEm: string;
  status: SolicitacaoStatus;
  proposta?: Proposta;
  contraproposta?: string;
  aprovadoEm?: string;
  confirmadoEm?: string;
}

const KEY = "solana-solicitacoes";

function persist(todas: Solicitacao[]) {
  if (typeof window === "undefined") return todas;
  window.localStorage.setItem(KEY, JSON.stringify(todas));
  return todas;
}

export function loadSolicitacoes(): Solicitacao[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Solicitacao[]) : [];
  } catch {
    return [];
  }
}

export function addSolicitacao(s: Omit<Solicitacao, "id" | "criadoEm" | "status">) {
  const nova: Solicitacao = {
    ...s,
    id: `sol-${Date.now()}`,
    criadoEm: new Date().toISOString(),
    status: "enviada",
  };
  persist([nova, ...loadSolicitacoes()]);
  return nova;
}

const VALOR_BASE: Record<ServicoKey, number> = {
  limpeza: 380,
  manutencao: 620,
  vistoria: 450,
  expansao: 2890,
  duvida: 0,
};

function proximaData(diasAFrente: number) {
  const d = new Date();
  d.setDate(d.getDate() + diasAFrente);
  return d.toISOString().slice(0, 10);
}

function gerarAnexos(
  s: Solicitacao,
  rodada: number,
  valor: number,
  dataExecucao: string,
  janela: string,
): Anexo[] {
  const servicoTitulo =
    SERVICOS.find((x) => x.key === s.servico)?.titulo ?? "Serviço";
  const proposta: Anexo = {
    nome:
      rodada === 1
        ? `proposta-${s.id}.pdf`
        : `proposta-${s.id}-rev${rodada}.pdf`,
    titulo: rodada === 1 ? "Proposta comercial" : `Proposta comercial (rev. ${rodada})`,
    tamanhoKb: 118 + rodada * 7,
    paginas: [
      `${EMPRESA.nome}`,
      `${EMPRESA.cidade} | ${EMPRESA.telefone}`,
      "",
      `PROPOSTA COMERCIAL - REVISAO ${rodada}`,
      `Servico: ${servicoTitulo}`,
      `Valor total: ${formatBRLValor(valor)}`,
      `Data de execucao: ${formatDataCurta(dataExecucao)}`,
      `Janela de atendimento: ${janela}`,
      "",
      "Escopo incluido:",
      "- Deslocamento da equipe tecnica",
      "- Mao de obra especializada",
      "- Relatorio fotografico pos-atendimento",
      "",
      "Validade desta proposta: 15 dias.",
      "Pagamento: PIX ou cartao em ate 3x sem juros.",
    ],
  };
  const contrato: Anexo = {
    nome: `contrato-servico-${s.id}.pdf`,
    titulo: "Contrato de prestação de serviço",
    tamanhoKb: 96,
    paginas: [
      `${EMPRESA.nome}`,
      "",
      "CONTRATO DE PRESTACAO DE SERVICOS",
      `Objeto: ${servicoTitulo}`,
      `Valor acordado: ${formatBRLValor(valor)}`,
      `Execucao prevista: ${formatDataCurta(dataExecucao)} (${janela})`,
      "",
      "Clausula 1 - A CONTRATADA executara o servico descrito no objeto,",
      "seguindo as normas tecnicas aplicaveis a sistemas fotovoltaicos.",
      "",
      "Clausula 2 - Garantia de 90 dias sobre a mao de obra executada.",
      "",
      "Clausula 3 - Reagendamentos devem ser comunicados com 24h",
      "de antecedencia, sem custo adicional.",
      "",
      `Contato: ${EMPRESA.email} | ${EMPRESA.horario}`,
    ],
  };
  return [proposta, contrato];
}

/** Resposta da instaladora: gera a proposta comercial da solicitação. */
export function responderSolicitacao(id: string): Solicitacao[] {
  const todas = loadSolicitacoes().map((s) => {
    if (s.id !== id) return s;
    const rodada = (s.proposta?.rodada ?? 0) + 1;
    const base = VALOR_BASE[s.servico] || 250;
    // A cada renegociação a equipe melhora a condição.
    const valor = Math.round(base * (1 - (rodada - 1) * 0.08));
    const dataExecucao = proximaData(2 + rodada * 2);
    const janela = rodada % 2 === 0 ? "13h às 17h" : "8h às 12h";
    return {
      ...s,
      status: "proposta" as SolicitacaoStatus,
      proposta: {
        valor,
        dataExecucao,
        janela,
        observacao:
          rodada === 1
            ? "Inclui deslocamento, mão de obra e relatório fotográfico."
            : "Condição revisada conforme sua contraproposta.",
        respondidoEm: new Date().toISOString(),
        rodada,
        anexos: gerarAnexos(s, rodada, valor, dataExecucao, janela),
      },
    };
  });
  return persist(todas);
}

/** Monta um PDF simples (uma página) a partir das linhas do anexo. */
function montarPdf(anexo: Anexo): Blob {
  const esc = (t: string) =>
    t.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
  const linhas = anexo.paginas
    .map((l, i) => `BT /F1 ${i === 3 || i === 2 ? 13 : 11} Tf 56 ${740 - i * 22} Td (${esc(l)}) Tj ET`)
    .join("\n");
  const content = `q 0.35 0.30 0.75 rg 0 812 612 30 re f Q\n${linhas}`;
  const objs = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  objs.forEach((o, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xrefStart = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((off) => {
    pdf += `${String(off).padStart(10, "0")} 00000 n \n`;
  });
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
  return new Blob([pdf], { type: "application/pdf" });
}

/** Abre o anexo em uma nova aba do navegador. */
export function abrirAnexo(anexo: Anexo) {
  if (typeof window === "undefined") return;
  const url = URL.createObjectURL(montarPdf(anexo));
  window.open(url, "_blank", "noopener");
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

/** Baixa o anexo como arquivo PDF. */
export function baixarAnexo(anexo: Anexo) {
  if (typeof window === "undefined") return;
  const url = URL.createObjectURL(montarPdf(anexo));
  const a = document.createElement("a");
  a.href = url;
  a.download = anexo.nome;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}


export function aprovarProposta(id: string): Solicitacao[] {
  return persist(
    loadSolicitacoes().map((s) =>
      s.id === id
        ? {
            ...s,
            status: "aprovada" as SolicitacaoStatus,
            aprovadoEm: new Date().toISOString(),
          }
        : s,
    ),
  );
}

/** Instaladora confirma o aceite do serviço e do contrato pelo cliente. */
export function confirmarServico(id: string): Solicitacao[] {
  return persist(
    loadSolicitacoes().map((s) =>
      s.id === id && s.status === "aprovada"
        ? {
            ...s,
            status: "confirmada" as SolicitacaoStatus,
            confirmadoEm: new Date().toISOString(),
          }
        : s,
    ),
  );
}

export function renegociarProposta(id: string, texto: string): Solicitacao[] {
  return persist(
    loadSolicitacoes().map((s) =>
      s.id === id
        ? { ...s, status: "renegociando" as SolicitacaoStatus, contraproposta: texto }
        : s,
    ),
  );
}

/** Cliente recusa a oferta apresentada, mas mantém a solicitação registrada. */
export function recusarProposta(id: string): Solicitacao[] {
  return persist(
    loadSolicitacoes().map((s) =>
      s.id === id ? { ...s, status: "recusada" as SolicitacaoStatus } : s,
    ),
  );
}

/** Cliente desiste da solicitação por completo. */
export function cancelarSolicitacao(id: string): Solicitacao[] {
  return persist(
    loadSolicitacoes().map((s) =>
      s.id === id ? { ...s, status: "cancelada" as SolicitacaoStatus } : s,
    ),
  );
}

/** Remove a solicitação do histórico. */
export function removerSolicitacao(id: string): Solicitacao[] {
  return persist(loadSolicitacoes().filter((s) => s.id !== id));
}

export function formatBRLValor(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function formatDataCurta(iso: string) {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export function whatsappLink(texto: string) {
  return `https://wa.me/${EMPRESA.whatsapp}?text=${encodeURIComponent(texto)}`;
}

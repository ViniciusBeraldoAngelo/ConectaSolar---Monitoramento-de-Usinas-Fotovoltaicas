// Sessão local (mock) — será substituída por backend real depois.

const KEY = "solana-session";
export const AUTH_EVENT = "solana-auth-changed";

export interface Session {
  email: string;
  entrouEm: string;
}

export function getSession(): Session | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}

export function signIn(email: string) {
  const session: Session = { email, entrouEm: new Date().toISOString() };
  window.localStorage.setItem(KEY, JSON.stringify(session));
  window.dispatchEvent(new Event(AUTH_EVENT));
  return session;
}

export function signOut() {
  window.localStorage.removeItem(KEY);
  window.dispatchEvent(new Event(AUTH_EVENT));
}

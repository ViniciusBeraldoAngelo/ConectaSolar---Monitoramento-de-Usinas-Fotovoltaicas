// Dados de demonstração da usina solar — gerados de forma determinística.

export type PeriodKey = "dia" | "semana" | "mes" | "ano" | "periodo";

export interface EnergyPoint {
  label: string;
  kwh: number;
}

export interface Invoice {
  id: string;
  mes: string;
  competencia: string;
  consumoKwh: number;
  valor: number;
  vencimento: string;
  status: "paga" | "pendente" | "vencida";
  concessionaria: string;
}

// Gerador pseudo-aleatório determinístico (evita Math.random no escopo de módulo).
function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function getGenerationData(period: PeriodKey): EnergyPoint[] {
  const rand = seeded(
    period === "dia" ? 11 : period === "semana" ? 23 : period === "mes" ? 37 : 53,
  );
  const pts: EnergyPoint[] = [];

  if (period === "dia" || period === "periodo") {
    // Curva solar horária (06h às 19h)
    const horas = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];
    for (const h of horas) {
      const t = (h - 6) / 13;
      const curva = Math.sin(t * Math.PI);
      pts.push({
        label: `${String(h).padStart(2, "0")}h`,
        kwh: +(curva * (5.2 + rand() * 1.4)).toFixed(1),
      });
    }
    return pts;
  }

  if (period === "semana") {
    const dias = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
    for (const d of dias) {
      pts.push({ label: d, kwh: +(28 + rand() * 22).toFixed(1) });
    }
    return pts;
  }

  if (period === "mes") {
    for (let d = 1; d <= 30; d++) {
      const sol = 0.55 + rand() * 0.45; // variação de nebulosidade
      pts.push({ label: String(d), kwh: +(44 * sol).toFixed(1) });
    }
    return pts;
  }

  // ano
  const meses = [
    "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
    "Jul", "Ago", "Set", "Out", "Nov", "Dez",
  ];
  meses.forEach((m, i) => {
    // Sazonalidade: mais sol no verão (hemisfério sul)
    const saz = 1 + 0.3 * Math.cos(((i - 0) / 12) * 2 * Math.PI);
    pts.push({ label: m, kwh: +(980 * saz * (0.92 + rand() * 0.16)).toFixed(0) });
  });
  return pts;
}

export function getInvoices(): Invoice[] {
  const base: Array<[string, string, number, number, string, Invoice["status"]]> = [
    ["Ago 2026", "08/2026", 412, 96, "10/09/2026", "pendente"],
    ["Jul 2026", "07/2026", 388, 74, "12/08/2026", "paga"],
    ["Jun 2026", "06/2026", 431, 88, "10/07/2026", "paga"],
    ["Mai 2026", "05/2026", 405, 61, "11/06/2026", "paga"],
    ["Abr 2026", "04/2026", 374, 55, "10/05/2026", "paga"],
    ["Mar 2026", "03/2026", 448, 102, "12/04/2026", "paga"],
    ["Fev 2026", "02/2026", 396, 68, "10/03/2026", "paga"],
    ["Jan 2026", "01/2026", 463, 118, "11/02/2026", "paga"],
  ];
  return base.map(([mes, comp, consumo, valor, venc, status], i) => ({
    id: `fatura-${i}`,
    mes,
    competencia: comp,
    consumoKwh: consumo,
    valor,
    vencimento: venc,
    status,
    concessionaria: "CPFL Energia",
  }));
}

export interface Settings {
  nome: string;
  foto: string | null;
  tema: "claro" | "escuro";
  destaque: "roxo" | "azul" | "violeta";
  usina: string;
}

export const DEFAULT_SETTINGS: Settings = {
  nome: "Vinicius Beraldo",
  foto: null,
  tema: "claro",
  destaque: "roxo",
  usina: "Usina Residencial — São Paulo",
};

const KEY = "solana-settings";

export function loadSettings(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: Settings) {
  window.localStorage.setItem(KEY, JSON.stringify(s));
}

export function applyTheme(tema: Settings["tema"], destaque: Settings["destaque"]) {
  const root = document.documentElement;
  root.classList.toggle("dark", tema === "escuro");
  if (destaque === "roxo") root.removeAttribute("data-accent");
  else root.setAttribute("data-accent", destaque);
}

export function formatKwh(v: number) {
  return v.toLocaleString("pt-BR", { maximumFractionDigits: 1 });
}

export function formatBRL(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

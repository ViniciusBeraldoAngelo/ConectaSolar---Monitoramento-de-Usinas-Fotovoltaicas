const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3458;
const serverDir = path.join(__dirname, "..", "dist", "server");
const clientDir = path.join(__dirname, "..", "dist", "client");

const mimeTypes = {
  ".js": "application/javascript",
  ".css": "text/css",
  ".ico": "image/x-icon",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
};

async function start() {
  const mod = await import(path.join(serverDir, "index.mjs"));
  const handler = mod.default;

  const server = http.createServer(async (req, res) => {
    try {
      const pathname = req.url.split("?")[0];

      const assetPath = path.join(clientDir, pathname);
      if (pathname.startsWith("/assets/") || pathname === "/favicon.ico" || pathname === "/robots.txt") {
        if (fs.existsSync(assetPath) && fs.statSync(assetPath).isFile()) {
          const ext = path.extname(assetPath);
          res.writeHead(200, { "Content-Type": mimeTypes[ext] || "application/octet-stream" });
          res.end(fs.readFileSync(assetPath));
          return;
        }
      }

      const request = new Request(`http://localhost:${PORT}${req.url}`);
      const response = await handler.fetch(request, {}, { waitUntil: () => {} });

      res.statusCode = response.status;
      res.statusMessage = response.statusText;
      response.headers.forEach((value, key) => res.setHeader(key, value));

      if (response.body) {
        const reader = response.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(value);
        }
      }
      res.end();
    } catch (err) {
      console.error(err);
      res.statusCode = 500;
      res.end("Internal Server Error");
    }
  });

  server.listen(PORT, () => console.log(`Solana server running on http://localhost:${PORT}`));
}

start();
